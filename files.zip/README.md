# Grounded SAM 2 with Category-Based Segmentation (OpenSeeD-Style)

[Shuo Shen](https://github.com/ShuoShenDe)

Built on top of **[Grounded SAM 2](https://github.com/IDEA-Research/Grounded-SAM-2)** ([SAM 2](https://arxiv.org/abs/2408.00714) + [Grounding DINO](https://arxiv.org/abs/2303.05499) / [DINO-X](https://arxiv.org/abs/2411.14347)).

[[`SAM 2 Paper`](https://arxiv.org/abs/2408.00714)] [[`Grounding DINO Paper`](https://arxiv.org/abs/2303.05499)] [[`OpenSeeD Paper`](https://arxiv.org/abs/2303.08131)] [[`BibTeX`](#citation)]

---

## What's Different in This Fork

The original Grounded SAM 2 takes a **free-form text prompt** and grounds whatever the user types. While powerful, this is hard to use as a stable upstream component for downstream tasks (autonomous driving, scene parsing, dataset auto-labeling), where you need:

- **A fixed taxonomy** with deterministic class IDs and colors
- **Dense semantic-segmentation-style outputs** (every pixel assigned a class), not just instance masks
- **Reproducible visualizations** across frames / videos

This fork rewires the pipeline into an **OpenSeeD-style closed-set segmentation system**: detections from Grounding DINO / DINO-X are mapped onto a small, fixed category set, SAM 2 produces per-instance masks, and masks belonging to the same category are merged and rendered with a fixed color palette.

## Pipeline Overview

```
Image
  │
  ▼
[1] Open-Vocabulary Detection         ← Grounding DINO / DINO-X
        produces  (bbox, fine_class_name, score)
  │
  ▼
[2] Category Mapping                  ← fine_class_name  →  category_id
        e.g. "car" / "truck" / "bus"  →  1 (Vehicle)
             "tree" / "bush"          →  8 (Vegetation)
  │
  ▼
[3] Mask Generation                   ← SAM 2
        per-instance binary masks from bbox prompts
  │
  ▼
[4] Per-Category Merging + Coloring
        masks of the same category_id are unioned
        rendered with a fixed palette → semantic color map
```

Step [1] is the *feature extraction* stage (the bbox visualization). Step [4] is the final *category color map* used downstream.

## Category Definitions

| ID | Category         | Color (in vis) | Typical fine-grained classes mapped here     |
|:--:|:-----------------|:---------------|:---------------------------------------------|
| 1  | Vehicle          | Crimson        | car, truck, bus, van                         |
| 2  | Cycle            | Orange         | bicycle, motorcycle, scooter                 |
| 3  | Pedestrian       | Magenta        | person, pedestrian                           |
| 4  | Road             | Steel Blue     | road                                         |
| 5  | Sidewalk         | Yellow         | sidewalk, curb                               |
| 6  | Structure        | Brown          | building, wall, bridge, structure            |
| 8  | Vegetation       | Green          | tree, bush, plant                            |
| 11 | Traffic Facility | Cyan           | traffic light, traffic sign, pole, lamp post |
| 13 | Sky              | Light Blue     | sky                                          |

> The mapping is defined in `category_mapping.py` (or wherever you keep it). To add a new mapping, just append `{"fine_name": category_id}` — no model retraining needed.

## Results

Two real-world driving examples (Dutch roads). For each scene we show:
**Original → Detection (Step 1) → Category Color Map (Step 4)**

### Example 1 — open road approaching a signalized junction

| Original | Feature Extraction (bbox) | Category Segmentation |
|:---:|:---:|:---:|
| ![](./assets/category_seg/origin.png) | ![](./assets/category_seg/FeatureExtraction.png) | ![](./assets/category_seg/00_001100_color.png) |

### Example 2 — stopped behind two cars at a traffic light

| Original | Feature Extraction (bbox) | Category Segmentation |
|:---:|:---:|:---:|
| ![](./assets/category_seg/900origin.jpg) | ![](./assets/category_seg/900extract.jpg) | ![](./assets/category_seg/900color.jpg) |

Notes on the visualizations:
- Detection scores in the bbox figure are kept low (≈0.35–0.7) on purpose — the category-merging step is robust to a few false positives because masks of the same category are unioned, so duplicates don't matter.
- Pixels left **black** in the color map are unassigned (no detected category covered them) — useful for downstream filtering.

## Installation

Same as upstream Grounded SAM 2.

Download the pretrained `SAM 2` checkpoints:

```bash
cd checkpoints
bash download_ckpts.sh
```

Download the pretrained `Grounding DINO` checkpoints:

```bash
cd gdino_checkpoints
bash download_ckpts.sh
```

### Installation without docker

We use `python=3.10`, `torch >= 2.3.1`, `torchvision >= 0.18.1`, `cuda-12.1`. Install PyTorch first following [pytorch.org](https://pytorch.org/get-started/locally/):

```bash
pip3 install torch torchvision torchaudio
```

Make sure CUDA is set up correctly so Grounding DINO can compile its Deformable Attention op (see [Grounding DINO Installation](https://github.com/IDEA-Research/GroundingDINO?tab=readme-ov-file#hammer_and_wrench-install)):

```bash
export CUDA_HOME=/path/to/cuda-12.1/
```

Install `Segment Anything 2`:

```bash
pip install -e .
```

Install `Grounding DINO`:

```bash
pip install --no-build-isolation -e grounding_dino
```

### Installation with docker

```bash
cd Grounded-SAM-2
make build-image
make run
```

Working directory inside the container: `/home/appuser/Grounded-SAM-2`.

## Running the Category-Based Segmentation Demo

### Single image

```bash
python category_seg_demo.py \
    --image_path ./assets/category_seg/origin.png \
    --output_dir ./outputs/category_seg
```

This produces two files in `--output_dir`:
- `*_extract.jpg` — Step 1 detections (bbox + fine class names)
- `*_color.png` — Step 4 final category color map

### Batch / video

```bash
python category_seg_video.py \
    --video_dir ./assets/my_drive \
    --output_dir ./outputs/category_seg \
    --step 1
```

`--step` controls frame stride (use `--step 5` to process every 5th frame for a quick preview).

### Output format (JSON)

When `--dump_json` is set, each image also produces a JSON sidecar:

```python
{
    "image_path": "path/to/image.jpg",
    "img_width": w,
    "img_height": h,
    "annotations": [
        {
            "category_id": 1,
            "category_name": "Vehicle",
            "fine_class_name": "car",      # original Grounding DINO label
            "bbox": [x1, y1, x2, y2],
            "segmentation": {              # COCO RLE
                "size": [h, w],
                "counts": "..."
            },
            "score": 0.71
        }
    ]
}
```

Downstream code can either consume per-instance masks (group by `category_id`) or load the rendered `*_color.png` directly.

## Underlying Open-Vocabulary Demos (Inherited from Grounded SAM 2)

The original free-text-prompt demos still work — useful when you need to extend the category taxonomy or debug the detection stage on a new class.

- `python grounded_sam2_local_demo.py` — Grounding DINO + SAM 2, local checkpoint
- `python grounded_sam2_hf_model_demo.py` — Grounding DINO via HuggingFace
- `python grounded_sam2_dinox_demo.py` — DINO-X via DDS API (requires API token)
- `python grounded_sam2_tracking_demo.py` — video tracking with SAM 2 memory bank

> 🚨 If you hit HuggingFace network issues: `export HF_ENDPOINT=https://hf-mirror.com`.

For DINO-X / Grounding DINO 1.5 you'll need an API token: [request here](https://deepdataspace.com/request_api), then `pip install dds-cloudapi-sdk --upgrade`.

See the [original Grounded SAM 2 README](https://github.com/IDEA-Research/Grounded-SAM-2) for the full set of free-prompt demos (Florence-2 auto-labeling, SAHI tiled inference, continuous-ID video tracking, etc.).

## Latest Updates

- **Category-Based Segmentation pipeline** — new closed-set, OpenSeeD-style output mode with fixed 9-class taxonomy and deterministic color palette. Replaces free-text prompts as the recommended entry point for downstream perception tasks.
- Inherits all upstream Grounded SAM 2 capabilities: SAM 2.1 checkpoints, DINO-X integration, SAHI tiled inference, video tracking with continuous IDs.

## Citation

If you find this project useful, please consider citing the underlying works:

```bibtex
@misc{ravi2024sam2segmentimages,
      title={SAM 2: Segment Anything in Images and Videos},
      author={Nikhila Ravi and Valentin Gabeur and Yuan-Ting Hu and Ronghang Hu and Chaitanya Ryali and Tengyu Ma and Haitham Khedr and Roman Rädle and Chloe Rolland and Laura Gustafson and Eric Mintun and Junting Pan and Kalyan Vasudev Alwala and Nicolas Carion and Chao-Yuan Wu and Ross Girshick and Piotr Dollár and Christoph Feichtenhofer},
      year={2024},
      eprint={2408.00714},
      archivePrefix={arXiv},
      primaryClass={cs.CV},
      url={https://arxiv.org/abs/2408.00714}
}

@article{liu2023grounding,
  title={Grounding DINO: Marrying DINO with Grounded Pre-Training for Open-Set Object Detection},
  author={Liu, Shilong and Zeng, Zhaoyang and Ren, Tianhe and Li, Feng and Zhang, Hao and Yang, Jie and Li, Chunyuan and Yang, Jianwei and Su, Hang and Zhu, Jun and others},
  journal={arXiv preprint arXiv:2303.05499},
  year={2023}
}

@misc{ren2024grounded,
      title={Grounded SAM: Assembling Open-World Models for Diverse Visual Tasks},
      author={Tianhe Ren and Shilong Liu and Ailing Zeng and Jing Lin and Kunchang Li and He Cao and Jiayu Chen and Xinyu Huang and Yukang Chen and Feng Yan and Zhaoyang Zeng and Hao Zhang and Feng Li and Jie Yang and Hongyang Li and Qing Jiang and Lei Zhang},
      year={2024},
      eprint={2401.14159},
      archivePrefix={arXiv},
      primaryClass={cs.CV}
}

@inproceedings{zhang2023simple,
  title={A Simple Framework for Open-Vocabulary Segmentation and Detection},
  author={Zhang, Hao and Li, Feng and Zou, Xueyan and Liu, Shilong and Li, Chunyuan and Yang, Jianwei and Zhang, Lei},
  booktitle={ICCV},
  year={2023}
}

@article{kirillov2023segany,
  title={Segment Anything},
  author={Kirillov, Alexander and Mintun, Eric and Ravi, Nikhila and Mao, Hanzi and Rolland, Chloe and Gustafson, Laura and Xiao, Tete and Whitehead, Spencer and Berg, Alexander C. and Lo, Wan-Yen and Doll{\'a}r, Piotr and Girshick, Ross},
  journal={arXiv:2304.02643},
  year={2023}
}
```
